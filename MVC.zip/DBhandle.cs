﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment.Model
{
    public class DBhandle
    {
        public string viewcustomer()
        {
            CustomContext context = new CustomContext();
            var listP = from e in context.Customers
                        select new
                        {
                            CustomerId = e.CustomerId,
                            FirstName = e.FirstName,
                            LastName = e.LastName,
                            Country = e.Country,
                            CreatedDate = e.CreatedDate
                        };
            List<Customer> listS = new List<Customer>();
            foreach (var listE in listP)
            {
                Customer e = new Customer();
                e.CustomerId = listE.CustomerId;
                e.FirstName = listE.FirstName;
                e.LastName = listE.LastName;
                e.Country = listE.Country;
                e.CreatedDate = listE.CreatedDate;
                listS.Add(e);
            }

            return JsonConvert.SerializeObject(listS);
        }

        public void DeleteCus(int id)
        {
          CustomContext context = new CustomContext();
            context.Customers.Remove(context.Customers.FirstOrDefault(e => e.CustomerId == id));
            context.SaveChanges();
            return;
        }

        public void addcustomer(Customer c)
        {
            CustomContext context = new CustomContext();
            c.CreatedDate = DateTime.Now;
            context.Customers.Add(c);
            context.SaveChanges();
            return;
        }
        public Customer getcusonID(int CustomerId)
        {
            CustomContext context = new CustomContext();
            var cus = context.Customers.Find(CustomerId);
            return cus;
        }

        public void updatecustomer(Customer c)
        {
            CustomContext context = new CustomContext();
            Customer cus = context.Customers.Find(c.CustomerId);
            cus.FirstName = c.FirstName;
            cus.LastName = c.LastName;
            cus.Country = c.Country;

            context.SaveChanges();
            return;
        }
    }
}

    

