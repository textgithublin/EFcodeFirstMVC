﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment.Model
{
    public class CustomContext:DbContext
    {
        public string ConnectionString = "Server=DESKTOP-J8BUDV3\\SQLEXPRESS;Database=CustomerDB;Trusted_Connection=True;";
        protected override void OnConfiguring(DbContextOptionsBuilder optionsB)
        {
            optionsB.UseSqlServer(ConnectionString);
        }
        public DbSet<Customer> Customers { get; set; }
    }
}
